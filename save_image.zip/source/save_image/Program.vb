﻿'
' Created by SharpDevelop.
' User: bojan
' Date: 3/30/2025
' Time: 10:17 AM
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'

'Imports System.IO
'Imports System.Windows.Forms
'Imports System.Drawing 'no need if using full name space in code: system.drawing.bitmap. Has to be added as a reference using gui settings, though.

Module Program
	Sub Main()
		
		'Path.Combine(Path.GetTempPath(),"name.png")

		Dim stDateTime As String = System.DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss-fffffff")
		stDateTime = System.DateTime.Now.ToString("yyyy-MM-dd_HHmmss")
		
		Dim intCounter As Integer = 0
		Dim arArguments As String() = Environment.GetCommandLineArgs
		If arArguments.Length > 1 Then ' length 2 or more, at least first argument	
			stDateTime = arArguments(1)
		End If
		
		Dim stImagePathAndFIlename As String = System.Windows.Forms.Application.StartupPath & System.IO.Path.DirectorySeparatorChar & stDateTime & ".png"
		If System.Windows.Forms.Clipboard.ContainsImage() Then
			
			Dim newImage As New System.Drawing.Bitmap(System.Windows.Forms.Clipboard.GetImage)
			
			'If System.IO.File.Exists(stImagePathAndFIlename)
			While System.IO.File.Exists(stImagePathAndFIlename)
				intCounter = intCounter + 1
				stImagePathAndFIlename = System.Windows.Forms.Application.StartupPath & System.IO.Path.DirectorySeparatorChar & stDateTime & "_" & Convert.ToString(intCounter) & ".png"	
			End While
			'End if
			
			'Console.Write(stImagePathAndFIlename)
			newImage.Save(stImagePathAndFIlename)
		End If
		
		
		'Console.Write("Press any key to continue . . . ")
		'Console.ReadKey(True)
		
	End Sub
End Module
